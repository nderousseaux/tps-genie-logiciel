# -*- coding: utf-8 -*-
from setuptools import setup, find_packages

setup(
    name='fizzbuzz',
    version='1.0.0',
    author='Nathanaël Derousseaux',
    author_email='nathanael.derousseaux-lebert@etu.unistra.fr',
    description='Réalisation du TP 02',
    packages=find_packages(),
)
